#ifndef TRANSLATE
#define TRANSLATE

inline int translate(int, int*, int*);
int* get_pot_list(int, int);
int* translate_sequence(char*, int, int, int, int*);
int* new_alphabet(char*);
#endif

#ifndef LINSPACE
#define LINSPACE

#include "alignment.h"

alignment* linear_space_alignment(char*, char*, int (*)(char,char),int*);
int unity (char, char);
#endif
